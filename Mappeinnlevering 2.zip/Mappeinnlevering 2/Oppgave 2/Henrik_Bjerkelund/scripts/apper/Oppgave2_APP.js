var Oppgave2_APP = {
    
    
init: function(){
    
    
    var MF = Oppgave2_APP;
    
    //HTML objects
    var $ManuBtn;
    var $RealBtn;
    var $barcaBtn;
    var juveBtn;
    var $outPut;
    
    var setHTMLObjects = function(){
        MF.$ManuBtn = $("#ManuBtn");
        MF.$Realbtn = $("#RealBtn");
        MF.$barcaBtn = $("#BarcBtn");
        MF.$juveBtn = $("#JuveBtn");
        MF.outPut = $("#outPut");
     
    }();
    var manuArray = Oppgave2_MODULE.showManu();
     function showManu(){
         $("#outPut article").remove();
       $.each(manuArray ,function(key, team){
           var $newArticle = $("<article>");
           var $newTitle = $("<h2>")
           .html(team.title);
           var $newPhoto = $("<img>")
           .attr("src",team.photo);
           var $history = $("<p>")
           .html(team.history);
         
           
           $newArticle.append($newTitle,$newPhoto,$history);
           $("#outPut").append($newArticle)
          }); 
            $("img")
                .animate(
                    {
                        width: "+=100px"                    
                    },
                    1000
                )
                .animate(
                    {
                        height: "+=100px"                    
                    },
                    1000
                )
                 $("img")
         .css("opacity", "0.3")
         .mouseenter(function()
                     {
             $(this).stop().fadeTo(800, 1);
         })
         .mouseleave(function()
                     {
             $(this).stop().fadeTo(800, 0.3);
         });
   }
    var realArray = Oppgave2_MODULE.showReal();
     function showReal(){
         $("#outPut article").remove();
       $.each(realArray ,function(key, team){
           var $newArticle = $("<article>");
           var $newTitle = $("<h2>")
           .html(team.title);
           var $newPhoto = $("<img>")
           .attr("src",team.photo);
           var $history = $("<p>")
           .html(team.history);
         
           
            $newArticle.append($newTitle,$newPhoto,$history);
           $("#outPut").append($newArticle)
          }); 
            $("img")
                .animate(
                    {
                        width: "+=100px"                    
                    },
                    1000
                )
                .animate(
                    {
                        height: "+=100px"                    
                    },
                    1000
                )
                 $("img")
         .css("opacity", "0.3")
         .mouseenter(function()
                     {
             $(this).stop().fadeTo(800, 1);
         })
         .mouseleave(function()
                     {
             $(this).stop().fadeTo(800, 0.3);
         });
   }
        var barcaArray = Oppgave2_MODULE.showBarca();
     function showBarca(){
         $("#outPut article").remove();
       $.each(barcaArray ,function(key, team){
           var $newArticle = $("<article>");
           var $newTitle = $("<h2>")
           .html(team.title);
           var $newPhoto = $("<img>")
           .attr("src",team.photo);
           var $history = $("<p>")
           .html(team.history);
         
           
            $newArticle.append($newTitle,$newPhoto,$history);
           $("#outPut").append($newArticle)
          }); 
            $("img")
                .animate(
                    {
                        width: "+=100px"                    
                    },
                    1000
                )
                .animate(
                    {
                        height: "+=100px"                    
                    },
                    1000
                )
                 $("img")
         .css("opacity", "0.3")
         .mouseenter(function()
                     {
             $(this).stop().fadeTo(800, 1);
         })
         .mouseleave(function()
                     {
             $(this).stop().fadeTo(800, 0.3);
         });
   }
    
        var juveArray = Oppgave2_MODULE.showJuve();
     function showJuve(){
         $("#outPut article").remove();
       $.each(juveArray ,function(key, team){
           var $newArticle = $("<article>");
           var $newTitle = $("<h2>")
           .html(team.title);
           var $newPhoto = $("<img>")
           .attr("src",team.photo);
           var $history = $("<p>")
           .html(team.history);
         
           
            $newArticle.append($newTitle,$newPhoto,$history);
           $("#outPut").append($newArticle)
          });  
         $("img")
                .animate(
                    {
                        width: "+=100px"                    
                    },
                    1000
                )
                .animate(
                    {
                        height: "+=100px"                    
                    },
                    1000
                )
         $("img")
         .css("opacity", "0.3")
         .mouseenter(function()
                     {
             $(this).stop().fadeTo(800, 1);
         })
         .mouseleave(function()
                     {
             $(this).stop().fadeTo(800, 0.3);
         });
        
         
   }
    

     
 
    /* This function will display arrayListes i have made*/
    var setEvents = function(){
        
        
        MF.$ManuBtn.on("click", function(){
        showManu();
            
        
    });
        MF.$Realbtn.on("click", function(){
            showReal();
        });
        
        MF.$barcaBtn.on("click", function(){
            showBarca();
        });
    
        MF.$juveBtn.on("click", function(){
            showJuve();
        });
    
       
    
}();
    
  

    

}, //--end init
    
}; //end MITTFERIESTED_APP
    
//kaller på init-funksjonen til MITTFERIESTED_APP
