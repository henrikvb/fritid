$(function(){
    Oppgave2_APP.init();
});