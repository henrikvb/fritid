var Oppgave2_MODULE = (function(){

    
 
    
      var manchesterUnitedJSON = {manuList:[
       {"title": "Manchester United", "photo":"Pictures/manuteam.jpeg", 
       "history":"Manchester United Football Club is a professional football club based in Old Trafford, Greater Manchester, England, that competes in the Premier League, the top flight of English football. Nicknamed the Red Devils, the club was founded as Newton Heath LYR Football Club in 1878, changed its name to Manchester United in 1902 and moved to its current stadium, Old Trafford, in 1910"}
   ]
                              };
           var barelonaJSON = {barcaList:[
       {"title": "Barcelona", "photo":"Pictures/barceteam.jpg", 
       "history":"Barcelona and familiarly as Barça, is a professional football club based in Barcelona, Catalonia, Spain. Founded in 1899 by a group of Swiss, English and Catalan footballers led by Joan Gamper, the club has become a symbol of Catalan culture and Catalanism, hence the motto Més que un club(English: More than a club). Unlike many other football clubs, the supporters own and operate Barcelona. It is the second most valuable sports team in the world, worth $3.56 billion, and the world's second richest football club in terms of revenue, with an annual turnover of €560.8 million.[2][3] The official Barcelona anthem is the Cant del Barça, written by Jaume Picas and Josep Maria Espinàs.[4]"}
   ]
                              };
       var realMadridJSON = {realList:[
       {"title": "Real Madrid", "photo":"Pictures/realteam.jpg", 
       "history":"Real Madrid, or simply as Real, is a professional football club based in Madrid, Spain. Founded in 1902 as Madrid Football Club, the club has traditionally worn a white home kit since inception. The word Real is Spanish for Royal and was bestowed to the club by King Alfonso XIII in 1920 together with the royal crown in the emblem. The team has played its home matches in the 81,044-capacity Santiago Bernabéu Stadium in downtown Madrid since 1947. Unlike most European sporting entities, Real Madrid's members (socios) have owned and operated the club throughout its history"}
   ]
                              };
    
    
       var juventusJSON = {juveList:[
       {"title": "Juventus", "photo":"Pictures/juveteam.jpg", 
       "history":"Juventus Football Club S.p.A. colloquially known as Juve is a professional Italian association football club based in Turin, Piedmont, founded in 1897 by a group of young Torinese students,[2] among them was their first president Eugenio Canfari and his brother Enrico, author of the company's historical memory.[5][6][7] The club is the second oldest of its kind still active in the country after Genoa's football section (1893), has traditionally worn a black and white striped home kit since 1903 and has played its home matches in several grounds, being the latest the 41,507-capacity Juventus Stadium. Juventus is also the most successful club in Italian football, the one that has the most sporting tradition in the country[8][9] and one of the most awarded globally[10][11][12] having won overall sixty-three official titles on the national and international stage, more than any other club in Italy: a record thirty-three official league titles, a record twelve Coppa Italia titles, a record seven Supercoppa Italiana titles and, with eleven titles in confederation and inter-confederation competitions (two Intercontinental Cups, two European Champion Clubs' Cup/UEFA Champions Leagues, one European Cup Winners' Cup, three UEFA Cups, two UEFA Super Cups and one UEFA Intertoto Cup) it ranks fourth in Europe and eighth in the world with the most trophies won."}
   ]
                              };
    
    
    
    var showManu = function(){
        return manchesterUnitedJSON.manuList;
    }
    var showReal = function(){
        return realMadridJSON.realList;
    }
      var showBarca = function(){
        return barelonaJSON.barcaList;
    }
 
      var showJuve = function(){
          return juventusJSON.juveList;
      }
  
    
    return {
        showManu: showManu,
        showReal : showReal,
        showBarca : showBarca,
        showJuve : showJuve
}
  
            }());
