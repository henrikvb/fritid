$(function(){

            //HTML-objekter
            var $newDiv;
            var $generateDivsBtn;
            var $generatedDivs;

            var init = function(){
                var setHTMLObjects = function(){
                    $newDiv = $("#newDiv");
                    $generateDivsBtn = $("#generateDivsBtn");
                    $generatedDivs = $("#generatedDivs");
                }();//end HTML-objects
              
            var setEvents = function(){
                //Oppretter nye diver basert på brukerinput
                $generateDivsBtn.click(function(){
                    $("#generatedDivs").empty();
                    var newDiv = $newDiv.val();
                    if (newDiv > 0) {
                    for (i=0; i < newDiv; i++) {
                    $('<div id="addedDivsValue' + i + '"/>').text(i+1).appendTo("#generatedDivs");
                        
                     //Stilsetter de genrerte divene      
                    $("#generatedDivs div").css(
                  {
                      "height": "50px",
                      "width": "50px",
                      "background": "aqua",
                      "color":"yellow",
                      "display": "inline-block",
                      "margin":"10px",
                      "text-align":"center"
                  }
              ); 
                    //Stilestter de genrerete divene med opacity ved mouseenter og mouseleave    
                   $("#generatedDivs div")
                       .css("opacity", "0.5")
                       .mouseenter(function(){
                       $(this).stop()
                       .fadeTo(800,1);
                           
                   })
                    .mouseleave(function(){
                       $(this).stop().fadeTo(800, 0.5);
                   });
                            
                //Stilsetter diven du klikker på, den forrige diven og den neste diven lilla            
                $("#generatedDivs div")
                            .click(function(){
                    $(this).css("background", "purple").next().add($(this).prev()).css("background","purple")
                    
                });
                     
                //Stilsetter alle divene utenom den du klikker på grønne        
                $("#generatedDivs div").dblclick(function(){
                    $(this).css("background","black").nextAll().add($(this).prevAll()).css("background","green")
                });
                            
                            
                    }
                }
            return false;         
                  
                });


        }();//end setEvents
                
    }();//end init

});


