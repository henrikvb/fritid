$(function(){
    MITTFERIESTED_APP.init();
});