var MITTFERIESTED_MODULE = (function(){

    
    var holidaylistJSON = {holidayList:[
        {"country": "England", "city": "London", "photoOfCity": "images/london.jpeg"},
        {"country": "England", "city": "Brighton", "photoOfCity": "images/brighton.jpeg"},
        {"country": "Frankrike", "city": "Paris", "photoOfCity": "images/paris.jpeg"},
        {"country": "Frankrike", "city": "Nice", "photoOfCity": "images/nice.jpeg"},
        {"country": "Tyskland", "city": "Berlin", "photoOfCity": "images/berlin.jpeg"},
        {"country": "Tyskland", "city": "Cologne", "photoOfCity": "images/cologne.jpeg"},
        {"country": "USA", "city": "New York", "photoOfCity": "images/newyork.jpeg"},
        {"country": "USA", "city": "California", "photoOfCity": "images/california.jpeg"},
        {"country": "Norge", "city": "Oslo", "photoOfCity": "images/oslo.jpeg"},
        {"country": "Norge", "city": "Bergen", "photoOfCity": "images/bergen.jpeg"},
        {"country": "Spania", "city": "Madrid", "photoOfCity": "images/madrid.jpeg"},
        {"country": "Spania", "city": "Barcelona", "photoOfCity": "images/barcelona.jpeg"}
        
    ]
                          };
    
    
    //Returnerer alle destinasjoner
    var showAllDestinations = function(){
        return holidaylistJSON.holidayList;
    }
    
    //Returnerer destinasjoner basert på brukerinput
     var checkByAllCountries = function(countryname) {
        var newArray = new Array();
        for (var i = 0; i < holidaylistJSON.holidayList.length; i++) {
            var item = holidaylistJSON.holidayList[i];
            if(item.country == countryname){
                newArray.push(item);
            }
        };
        return newArray;
     }
  
    //Tilgjengeliggjør funksjonene utenfor modulen
    return {
        showAllDestinations: showAllDestinations,
        checkByAllCountries: checkByAllCountries    
}
  
            }());
