var MITTFERIESTED_APP = {
    
    
init: function(){
    
    
    var MF = MITTFERIESTED_APP;
    
    //HTML objects
    var $userInput;
    var $searchCountryBtn;
    var $allDestinationsBtn;
    var $output;
    
    var setHTMLObjects = function(){
        MF.$userInput = $("#userInput");
        MF.$searchCountryBtn = $("#searchCountryBtn");
        MF.$allDestinationsBtn = $("#allDestinationsBtn");
        MF.$output = $("#output");
    }
();
    
    //Oppretter nye HTML-objekter i et array fra JSON lista og displayer på nettsiden
    var destinationArray = MITTFERIESTED_MODULE.showAllDestinations();
     function showAllDestinations(){
         $("#output article").remove();
       $.each(destinationArray ,function(key, holiday){
           var $newArticle = $("<article>");
           var $newLand = $("<h2>")
           .html(holiday.country);
           var $newCity = $("<h3>")
           .html(holiday.city);
           var $newPhoto = $("<img>")
           .attr("src",holiday.photoOfCity);
           
           $newArticle.append($newLand,$newCity,$newPhoto);
           $("#output").append($newArticle)
          });  
   }
    
    
    //Henter brukeinput, oppretter nye HTML-objekter med elementene fra JSON lista og displayer på nettsiden
    var checkByAllCountries= function(){ 
    var userInput = $(MF.$userInput).val();
    var checkCity = MITTFERIESTED_MODULE.checkByAllCountries(userInput);
      $("#output article").remove();
            $.each(checkCity, function(key, holiday){
                var $newArticle = $("<article>");
                var $newLand = $("<h2>")
                   .html(holiday.country);
                var $newCity = $("<h3>")
                   .html(holiday.city);
                var $newPhoto = $("<img>")
                   .attr("src",holiday.photoOfCity);

                $newArticle.append($newLand,$newCity,$newPhoto);
                $("#output").append($newArticle)
            });
    }
  
      
    var setEvents = function(){
        
  
  MF.$allDestinationsBtn.on("click", function(){
        showAllDestinations();
        
    });
        
  MF.$searchCountryBtn.on("click", function(){
        checkByAllCountries();
    });
        
    
}();
    
    

}, //end init
    
}; //end MITTFERIESTED_APP
    
