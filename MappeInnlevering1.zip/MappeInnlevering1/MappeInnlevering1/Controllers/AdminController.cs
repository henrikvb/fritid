﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using MappeInnlevering1.Models;

namespace MappeInnlevering1.Controllers
{
    public class AdminController : Controller
    {
       
        public ActionResult LoginAdmin()
        {
          

            return View();
        }

        [HttpPost]
        public ActionResult LoginAdmin(Admin AdminLogin)
        {
            try
            {
                using (MoviePageEntities6 db = new MoviePageEntities6())
                {
                    var usr = db.Admin.Single(u => u.Email == AdminLogin.Email && u.Password == AdminLogin.Password);
                    if (usr != null)
                    {
                        Session["EmailID"] = usr.Email.ToString();
                        Session["Password"] = usr.Password.ToString();
                        return RedirectToRoute(new { controller = "Customer", action = "CustomerInfo" });
                    }
                    else
                    {
                        ModelState.AddModelError("","UserName or password Wrong");

                    }
                }
               
            }
            catch
            {
                ViewBag.Message = "Something wrong in database";
                return View();
            }

            return View();
        }

     
    }
    }