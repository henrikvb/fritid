﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MappeInnlevering1.Models;
using System.IO;

namespace MappeInnlevering1.Controllers
{
    public class CustomerController : Controller
    {

        // GET: Home
        public ActionResult HomePage()
        {
            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    var Productlist = (from product in dbkobling.Products
                                       select product).ToList();

                    return View(Productlist);
                }
            }
            catch (Exception exeption)
            {
                ViewBag.Feilmelding = exeption.Message;
                return View();
            }
        }

        public ActionResult TopMovie()
        {
            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    var Productlist = (



                    from product in dbkobling.Products
                    orderby product.ProductID descending
                    where product.ProductID <= 4
                    select product).ToList();


                    return View(Productlist);
                }
              
            }
            catch (Exception exeption)
            {
                ViewBag.Feilmelding = exeption.Message;
                return View();
            }

           
        }


        [HttpGet]
        public ActionResult RegisterCustomer()
        {

            return View();
        }

        [HttpPost]
        public ActionResult RegisterCustomer(Customer CustomerLogin)
        {
            if (ModelState.IsValid)
            {
                if (CustomerLogin.Name_ != String.Empty && CustomerLogin.LastName != String.Empty
                    && CustomerLogin.Email != String.Empty)
                {
                    ViewBag.Message = "Successfull registration";

                }
            }
            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    dbkobling.Customer.Add(CustomerLogin);
                    dbkobling.SaveChanges();

                    return RedirectToAction("HomePage");


                }

            }
            catch
            {
                ViewBag.Message = "Noe galt oppsto i kobling til DB";
                return View();
            }


        }

        public ActionResult ConfirmRegistration()
        {
            return View();
        }


        public ActionResult CustomerInfo()
        {
            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                  
                    var CustomerList = (from Customers in dbkobling.Customer

                                        select Customers).ToList();

                   
                    return View(CustomerList);
                }
            }
            catch
            {
                ViewBag.Message = "Something wrong in database";
                return View();
            }

        }
        [HttpGet]
        public ActionResult DeleteCustomer(int id)
        {
            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    var deletecustomer = (from Customers in dbkobling.Customer
                                          where Customers.Id == id
                                          select Customers).SingleOrDefault();

                    return View(deletecustomer);
                }
            }
            catch
            {
                ViewBag.Message = "Something wrong in database";
                return View();
            }

        }

        [HttpPost]
        public ActionResult DeleteCustomer(Customer CustomerLogin)
        {
            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    var deletecustomer = (from Customers in dbkobling.Customer
                                          where Customers.Id == CustomerLogin.Id
                                          select Customers).SingleOrDefault();

                    dbkobling.Customer.Remove(deletecustomer);
                    dbkobling.SaveChanges();

                    return RedirectToAction("CustomerInfo");
                }
            }
            catch
            {
                ViewBag.Message = "Something wrong in database";
                return View();
            }
        }
        [HttpGet]
        public ActionResult ChangeCustomerInfo(int id)
        {
            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    var changecustomerinfo = (from Customers in dbkobling.Customer
                                              where Customers.Id == id
                                              select Customers).SingleOrDefault();

                    return View(changecustomerinfo);
                }
            }
            catch
            {
                ViewBag.Message = "Something wrong in database";
                return View();
            }
        }

        [HttpPost]
        public ActionResult ChangeCustomerInfo(Customer CustomerLogin)
        {
            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    var changecustomerinfo = (from Customers in dbkobling.Customer
                                              where Customers.Id == CustomerLogin.Id
                                              select Customers).SingleOrDefault();

                    changecustomerinfo.Name_ = CustomerLogin.Name_;
                    changecustomerinfo.LastName = CustomerLogin.LastName;
                    changecustomerinfo.Email = CustomerLogin.Email;

                    dbkobling.SaveChanges();

                    return RedirectToAction("CustomerInfo");
                }
            }
            catch
            {
                ViewBag.Message = "Something wrong in database";
                return View();
            }



        }


        public ActionResult AddNewMovie(int id)
        {
            Products pro = new Products();

            return View(pro);
        }

        [HttpPost]

        public ActionResult AddNewMovie(Products products, HttpPostedFileBase file)
        {

            if (file != null)
            {
                String filnavn = Path.GetFileName(file.FileName);
                String filsti = Path.Combine(Server.MapPath("~/Bilder"), filnavn);
                file.SaveAs(filsti);
                products.BildeSrc = filnavn;
            }
            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    dbkobling.Products.Add(products);
                    dbkobling.SaveChanges();
                }

                return RedirectToAction("CustomerInfo");
            }
            catch
            {
                ViewBag.Message = "Something wrong in database";
                return View();
            }
        }

        [HttpGet]
        public ActionResult DisplayAllMovies()
        {

            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    var Productlist = (from product in dbkobling.Products
                                       select product).ToList();

                    return View(Productlist);
                }
            }
            catch
            {
                ViewBag.Message = "Something wrong in database";
                return View();
            }
           
        }

        [HttpGet]
        public ActionResult DeleteMovie(int id)
        {

            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    var deletemovie = (from Prod in dbkobling.Products
                                       where Prod.ProductID == id
                                       select Prod).SingleOrDefault();

                    return View(deletemovie);
                }
            }
            catch
            {
                ViewBag.Message = "Something Wrong in database";
                return View();
            }
        



        }

        [HttpPost]
        public ActionResult DeleteMovie(Products products)
        {
            try
            {
                using (var dbkobling = new MoviePageEntities6())
                {
                    var deletemovie = (from Prod in dbkobling.Products
                                       where Prod.ProductID == products.ProductID
                                       select Prod).SingleOrDefault();

                    dbkobling.Products.Remove(deletemovie);
                    dbkobling.SaveChanges();

                    return RedirectToAction("CustomerInfo");
                }
            }
            catch
            {
                ViewBag.Message = "Something wrong in database";
                return View();
            }
        }

     

     
    }

}
