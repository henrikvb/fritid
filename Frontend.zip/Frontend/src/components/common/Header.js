import React from 'react';
import { Header} from '@intility/react-ui';
import  '../../styles/Header.css';
import { withRouter } from 'react-router-dom';

const navigation = (push) => ({
    "Forside": "http://google.com",
    "Logistikk": () => push("/"),
    "Dashboard Sales": "http://finn.no",
    "yolo": () => push("/yolo")
});

class header extends React.Component{
  render(){
    return(
      <div className="Header-container">
        <Header  title="Web" navigation={navigation(this.props.history.push)}/>
        <nav className="SecondaryNav"></nav>
      </div>
    );
  }
}
export default withRouter(header);
