import React, { Component } from 'react';
import {  } from '@intility/react-ui';
import '../../styles/Footer.css';

class Footer extends Component{
  render(){
    return(
      <div className="Footer">
        <p>@2018 Intility AS</p>
      </div>

    );
  }
}
export default Footer;
