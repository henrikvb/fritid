import React, { Component } from 'react';
import '../styles/App.css';
import Header from './common/Header';
import Contentbox from './webRegister/Contentbox';
import { IntilityApp } from '@intility/react-ui';
import Footer from './common/Footer';
import { Route, Switch, Link } from 'react-router-dom';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Header/>
        <Switch>
          <Route path="/yolo" component={() => <span>hello</span>}/>
          <Route path="/" component={Contentbox}/>
        </Switch>
        <Footer/>
      </div>
    );
  }
};

export default App;
