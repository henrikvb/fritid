import React from 'react';
import {ContentBox, Button} from '@intility/react-ui';

export default ({onClick}) =>
<form className="Installation-box">
  <div className="Button-Yes">
      <Button text="YES" onClick={() => alert("Run little dog")} color="green"></Button>
    </div>
    <div className="Button-No">
      <Button text="NO" onClick={() => alert("Hei")} color="red"></Button>
  </div>
</form>
