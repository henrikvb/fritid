import React from 'react';

export default ({}) =>

    <form className="Contentbox-form">
      <textarea className="Comment-box"></textarea>
    </form>
