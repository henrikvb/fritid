import React from 'react';

export default ({icon, title, onChange, placeholder, value, children}) =>
   <input onChange={onChange} className="Contentbox-Input" placeholder={placeholder} value={value}/>
