import React from 'react';
export default ({onChange, placeholder, id, value, className, children}) =>
<label>
    <input  onChange={onChange} className={className} placeholder={placeholder} id={id} value={value}/>
    {children}
</label>
