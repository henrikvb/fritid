import React, { Component } from 'react';
import { ContentRow, ContentBox, Button } from '@intility/react-ui';
import '../../styles/Contentbox.css';
import Input from './Input';
import TopInput from './TopInput';
import CommentBox from './CommentBox';
import Buttons from './Buttons';
import SummaryUsers from './SummaryUsers';
import RegisterBotton from './RegisterBotton';

class Contentbox extends Component{
  constructor(){
    super();
    this.state =  { caseNumber: "", user: "", csNumber: "", computer: "" , accessory: "",
    company: "", "userId":1006, "computerId":1, "expressInstall":false,};

  }
  oncaseNumberChange = e => this.setState({caseNumber: e.target.value});
  onUserChange = e => this.setState({user: e.target.value});
  oncsNumberChange = e => this.setState({csNumber: e.target.value});
  onComputerChange = e => this.setState({computer: e.target.value});
  onAccessorychange = e => this.setState({accessory: e.target.value});
  onCompanyChange = e=> this.setState({company: e.target.value});

  isFirstStageValid = () => this.state.caseNumber.length > 4 && this.state.user.length > 4 &&
  this.state.csNumber.length > 4 && this.state.company.length > 4;

  isSecondStageValid = () => this.state.accessory.length > 4 &&
  this.state.computer.length > 4;


  getActions () {
    return Object.keys(arguments).map(a => arguments[a].length > 4).includes(false)
      ? "check"
      : "check green";
  }


  submit (){
    let collection = {}
    collection.caseNumber = this.state.caseNumber,
    collection.csNumber = this.state.csNumber,
    collection.userId = this.state.userId,
    collection.computerId = this.state.computerId,
    collection.expressInstall = this.state.expressInstall,
    console.warn(collection);
    fetch('http://localhost:50650/api/weborders',{
      method:'POST',
      headers : new Headers ({
        'Content-Type':'application/json',
        'Accecpt' : 'application/json',
      }),
      body:JSON.stringify(
        collection,

      )
    }).then(results => {
      return results.json();
    }).then(results => {
        this.setState({results});
    }).catch(error => console.error('Error', error))

}
  render(){
    return(
      <ContentRow>
        <div className="Contentbox-top">
            <ContentBox
              title="Registrersak"
              icon={this.getActions(this.state.csNumber, this.state.caseNumber)}>
              <TopInput
                placeholder="CSsaksnummer"
                onChange={this.oncsNumberChange}
                value={this.state.csNumber}
                className={"Contentbox-Input" + (this.state.csNumber.length > 4 ? " greenBorder" : "")}
                />
              <TopInput
                placeholder="Ordernummer"
                onChange={this.oncaseNumberChange}
                value={this.state.caseNumber}
                className={"Contentbox-Input" + (this.state.caseNumber.length > 4 ? " greenBorder" : "")}/>
            </ContentBox>
            <ContentBox
                title="Registrersak"
                icon={this.getActions(this.state.user, this.state.company)}>
                <TopInput
                  placeholder="Firma"
                  type="text"
                  onChange={this.onCompanyChange}
                  value={this.state.company}
                  className={"Contentbox-Input" + (this.state.company.length > 4 ? " greenBorder" : "")}/>
                <TopInput
                  placeholder="Bruker"
                  type="text"
                  onChange={this.onUserChange}
                  value={this.state.user}
                  className={"Contentbox-Input" + (this.state.user.length > 4 ? " greenBorder" : "")}>
                  </TopInput>
            </ContentBox>
        </div>
        {
          this.isFirstStageValid() ?
            <div className="Contentbox-middle">
              <ContentBox title="Computer"
                icon={this.getActions(this.state.user, this.state.computer)}>
                <Input
                    onChange={this.onComputerChange}
                    placeholder="Modell"
                    type="text"
                    value={this.state.computer}
                    className={"Contentbox-Input" + (this.state.computer.length > 4 ? " greenBorder" : "")}/>
              </ContentBox>
              <ContentBox title="Tilbehør"
                icon={this.getActions(this.state.user, this.state.accessory)}>
              <Input
                onChange={this.onAccessorychange}
                  placeholder="Modell"
                  type="text"
                  value={this.state.accessory}
                  className={"Contentbox-Input" + (this.state.accessory.length > 4 ? " greenBorder" : "")}>
                </Input>
            </ContentBox>

              <ContentBox  title="Expressinstallasjon">
                <Buttons/>
              </ContentBox>
            </div> : null
        }
        {
          this.isSecondStageValid () ?
            <div className="Contentbox-bottom">
              <ContentBox title="Kommentar bruker">
              <CommentBox></CommentBox>
              </ContentBox>
              <ContentBox title="Kommentar logistikk">
              <CommentBox>
              </CommentBox>
            </ContentBox>
          </div> :null
        }
        {
          this.isSecondStageValid () ?
          <RegisterBotton>
            <Button onClick={() => this.submit()}  text="Registrer kunde" color="blue"/>
          </RegisterBotton> : null
        }

        {
          this.isSecondStageValid() ?
          <div className="Contentbox-summary-bottom">
          <ContentBox title="Oppsummering av brukere">
            <SummaryUsers summary={this.state.summary} />
          </ContentBox>
        </div> : null

        }
        </ContentRow>
    );
  }
}
export default Contentbox;
