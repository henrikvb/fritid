import React from 'react';
import '../../styles/Contentbox.css';
import { Button } from '@intility/react-ui'
export default ({id, children}) =>
<div className="Register-bottom">
  {children}
</div>
