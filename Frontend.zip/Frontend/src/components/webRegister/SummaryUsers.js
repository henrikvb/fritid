import React, { Component } from 'react';
import '../../styles/Contentbox.css';
import { Table } from '@intility/react-ui'

class SummaryUsers extends Component{
  constructor(props) {
         super(props);
         this.state = {
           summary:[ ]
         };
    }

    componentDidMount(){

    fetch('http://localhost:50650/api/users',
     {
      method: "GET",
    })
    .then(results => {
      return results.json();
    }).then(results => {
        this.setState({
          results
        });
    })
    console.log("state", this.state.summary);
  }

  render(){
  return this.state.results ? <Table items={this.state.results} keyMap={{
    userName: "Brukernavn",
    firstName: "Fornavn",
    lastName: "Etternavn",
    phoneNumber: "tlf",
    email: "E-postAdresse"
  }}/> : null;
}
}

export default SummaryUsers;
