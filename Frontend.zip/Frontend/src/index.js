import React from 'react';
import ReactDOM from 'react-dom';
import './styles/index.css';
import App from './components/App';
import createBrowserHistory from 'history/createBrowserHistory';
import registerServiceWorker from './registerServiceWorker';
import { Router } from 'react-router-dom';
import { IntilityApp } from '@intility/react-ui';

const history = createBrowserHistory();

ReactDOM.render(
  <Router history={history}>
    <IntilityApp>
      <App />
    </IntilityApp>
  </Router>,
  document.getElementById('root'));
registerServiceWorker();
